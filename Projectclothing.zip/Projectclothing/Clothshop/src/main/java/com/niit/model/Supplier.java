package com.niit.model;

public class Supplier {
private int supplierid;
private String suppliername;
private String companyname;
private String address;
private String emailid;
private int mobilenumber;

public int getSupplierid()
{
 return supplierid;
}
public void setSupplierid(int supplierid)
{
	this.supplierid=supplierid;
}
public String getSuppliername()
{
 return suppliername;
}
public void setSuppliername(String suppliername)
{
	this.suppliername=suppliername;
}
public String getCompanyname()
{
 return companyname;
}
public void setCompanyname(String companyname)
{
	this.companyname=companyname;
}
public String getAddress()
{
 return address;
}
public void setAddress(String address)
{
	this.address=address;
}
public String getEmailid()
{
 return emailid;
}
public void setEmailid(String emailid)
{
	this.emailid=emailid;
}
public int getMobilenumber()
{
 return mobilenumber;
}
public void setMobilenumber(int mobilenumber)
{
	this.mobilenumber=mobilenumber;
}
}
