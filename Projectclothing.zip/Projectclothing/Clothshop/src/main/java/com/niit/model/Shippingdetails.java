package com.niit.model;

public class Shippingdetails {
private int userid;
private int productid;
private String address;
private int deliverydate;
private String status;
private int amount;

public int getUserid()
{
 return userid;
}
public void setUserid(int userid)
{
	this.userid=userid;
}
public int getProductid()
{
 return productid;
}
public void setProductid(int productid)
{
	this.productid=productid;
}
public String getAddress()
{
 return address;
}
public void setAddress(String address)
{
	this.address=address;
}
public int getDeliverydate()
{
 return deliverydate;
}
public void setDeliverydate(int deliverydate)
{
	this.deliverydate=deliverydate;
}
public String getStatus()
{
 return status;
}
public void setStatus(String status)
{
	this.status=status;
}
public int getAmount()
{
 return amount;
}
public void setAmount(int amount)
{
	this.amount=amount;
}
}
