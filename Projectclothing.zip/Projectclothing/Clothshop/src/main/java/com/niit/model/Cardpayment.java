package com.niit.model;

public class Cardpayment {
private String cardholdername;
private int cardnumber;
private String cardtype;
private int cvvnumber;
private int expirydate;

public String getCardholdername()
{
 return cardholdername;
}
public void setCardholdername(String cardholdername)
{
	this.cardholdername=cardholdername;
}
public int getCardnumber()
{
 return cardnumber;
}
public void setCardnumber(int cardnumber)
{
	this.cardnumber=cardnumber;
}
public String getCardtype()
{
 return cardtype;
}
public void setCardtype(String cardtype)
{
	this.cardtype=cardtype;
}
public int getCvvnumber()
{
 return cvvnumber;
}
public void setCvvnumber(int cvvnumber)
{
	this.cvvnumber=cvvnumber;
}
public int getExpirydate()
{
 return expirydate;
}
public void setExpirydate(int expirydate)
{
	this.expirydate=expirydate;
}
}
