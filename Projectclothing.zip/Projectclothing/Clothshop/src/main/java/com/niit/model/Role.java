package com.niit.model;

public class Role {
private int userid;
private int roleid;
private String password;

public int getUserid()
{
 return userid;
}
public void setUserid(int userid)
{
	this.userid=userid;
}
public int getRoleid()
{
 return roleid;
}
public void setRoleid(int roleid)
{
	this.roleid=roleid;
}
public String getPassword()
{
 return password;
}
public void setPassword(String password)
{
	this.password=password;
}
}
