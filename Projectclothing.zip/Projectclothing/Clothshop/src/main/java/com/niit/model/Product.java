package com.niit.model;

public class Product {
	private int productid;
	private String productname;
	private int price;
	private String size;
	private String color;
	private String description;
	
	public int getProductid()
	{
	 return productid;
	}
	public void setProductid(int productid)
	{
		this.productid=productid;
	}
	public String getProductname()
	{
	 return productname;
	}
	public void setProductname(String productname)
	{
		this.productname=productname;
	}	
	public int getPrice()
	{
	 return price;
	}
	public void setPrice(int price)
	{
		this.price=price;
	}
	public String getSize()
	{
	 return size;
	}
	public void setSize(String size)
	{
		this.size=size;
	}
	public String getColor()
	{
	 return color;
	}
	public void setColor(String color)
	{
		this.color=color;
	}	
	public String getDescription()
	{
	 return description;
	}
	public void setDescription(String description)
	{
		this.description=description;
	}	
}
