package com.niit.model;

public class Codpayment {
private int userid;
private String address;
private int mobilenumber;
private int amount;

public int getUserid()
{
 return userid;
}
public void setUserid(int userid)
{
	this.userid=userid;
}
public String getAddress()
{
 return address;
}
public void setAddress(String address)
{
	this.address=address;
}
public int getMobilenumber()
{
 return mobilenumber;
}
public void setMobilenumber(int mobilenumber)
{
	this.mobilenumber=mobilenumber;
}
public int getAmount()
{
 return amount;
}
public void setAmount(int amount)
{
	this.amount=amount;
}
}
