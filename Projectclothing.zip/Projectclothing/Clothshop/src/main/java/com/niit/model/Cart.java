package com.niit.model;

public class Cart {
private int userid;
private int productid;
private int quantity;
private int price;
public int getUserid()
{
 return userid;
}
public void setUserid(int userid)
{
	this.userid=userid;
}
public int getProductid()
{
 return productid;
}
public void setProductid(int productid)
{
	this.productid=productid;
}
public int getQuantity()
{
 return quantity;
}
public void setQuantity(int quantity)
{
	this.quantity=quantity;
}
public int getPrice()
{
 return price;
}
public void setPrice(int price)
{
	this.price=price;
}
}
