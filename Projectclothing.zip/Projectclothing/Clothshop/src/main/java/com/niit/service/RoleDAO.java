package com.niit.service;

import java.util.List;

import com.niit.model.Role;
import com.niit.model.User;

public interface RoleDAO {
	public List<Role> getAllUsers();
	 public User getRole(int userid);
	 public void insertRole(User user);
	 public void updateRole(User user);
	 public void deleteRole(int id);
	 public void deleteAllRole(User user);
}
