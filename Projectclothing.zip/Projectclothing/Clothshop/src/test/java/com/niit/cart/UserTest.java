package com.niit.cart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.model.Role;
import com.niit.model.User;
import com.niit.service.RoleDAO;
import com.niit.service.UserDAO;

public class UserTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context =new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		System.out.println("system.....");
		
		UserDAO userDAO=(UserDAO) context.getBean("UserDAO");
		RoleDAO roleDAO=(RoleDAO) context.getBean("RoleDAO");
		
		
		User user=(User) context.getBean("user");
		Role role=(Role) context.getBean("role");
		
		user.setUsername("Ponmuthu");
		user.setPassword("muthu");
		user.setAddress("123,asdf");
		user.setEmailid("ponmuthu@gmail.com");
		user.setGender("male");
		user.setMobile_number(99999999);
 
		userDAO.insertUser(user);
		userDAO.deleteUser(4);
		
	}

}
